class PrinterJob implements Runnable {
    public void run() {
        System.out.println("Printing...");
    }
}