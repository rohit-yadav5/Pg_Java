public class IoTSensorMonitoring {
    public static void main(String[] args) {
        int num = 7;
        if (num % 2 == 0)
            System.out.println("Square: " + (num * num));
        else
            System.out.println("Cube: " + (num * num * num));
    }
}