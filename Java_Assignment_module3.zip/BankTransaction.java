class BankTransaction extends Thread {
    public void run() {
        System.out.println("Transaction processed");
    }
}